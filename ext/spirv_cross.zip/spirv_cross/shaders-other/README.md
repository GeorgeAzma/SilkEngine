These shaders are not actually run yet as part of any test suite,
but are kept here because they have been used to manually test various aspects of SPIRV-Cross in the past.

These would ideally be part of the test suite in some way.
